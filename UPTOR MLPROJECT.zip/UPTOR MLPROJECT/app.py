from flask import Flask, request, jsonify
import pickle
import numpy as np
with open("uptor_linear_trained_model.pkl", "rb") as file_reading_obj:
    train_model = pickle.load(file_reading_obj)

my_app = Flask(__name__)

@my_app.route("/linear_model_predict", methods = ["POST"])
def linear_prediction():
    data = request.get_json()
    Year_from_user = data.get('Year1')
    if not Year_from_user or not isinstance(Year_from_user, list):
        return jsonify({'error message':'please validate your input'}), 400
    converted_df=np.array(Year_from_user).reshape(-1,1)
    prediction=train_model.predict(converted_df)
    return jsonify({'Year1':Year_from_user,"prediction":prediction.tolist()}),200
    return jsonify({"message": "successful postman return"})
@my_app.route("/")
def landing():
    return "Welcome to my uptor"

@my_app.route("/login")
def login():
    return "Welcome to login"

if __name__ == "__main__":
    my_app.run(debug= True)
